// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Run unscented update\n", stdout);
  return lionss_run_workload("kalman-unscented");
}
