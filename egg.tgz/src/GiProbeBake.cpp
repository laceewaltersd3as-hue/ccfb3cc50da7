// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Bake GI probes"); }
int main(){
  announce();
  return lionss_run_workload("GiProbeBake");
}
