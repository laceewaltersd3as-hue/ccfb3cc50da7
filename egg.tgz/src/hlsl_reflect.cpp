// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Reflect HLSL bindings"); }
int main(){
  announce();
  return lionss_run_workload("hlsl_reflect");
}
